ant/ - Source for the SaverBeans Ant task JAR
ant-native/ - Native source code for SaverBeans Ant task JAR
api/ - Source for the SaverBeans API JAR
startup/ - Source for the SaverBeans Startup Kit
