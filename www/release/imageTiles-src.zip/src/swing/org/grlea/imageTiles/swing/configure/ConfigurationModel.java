package org.grlea.imageTiles.swing.configure;

// $Id:$
// Copyright (c) 2004 Graham Lea. All rights reserved.

// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import org.grlea.graphics.ImageFileFilter;
import org.grlea.imageTiles.ImageTilesHelper;
import org.grlea.imageTiles.TileRenderer;
import org.grlea.imageTiles.TileSpace;
import org.grlea.imageTiles.Transition;
import org.grlea.imageTiles.transition.BasicTransition;
import org.grlea.imageTiles.transition.SlideTransition;
import org.grlea.imageTiles.ImageSource;
import org.grlea.imageTiles.pipeline.Pipeline;
import org.grlea.imageTiles.pipeline.PipelineComponents;
import org.grlea.imageTiles.imageSource.DirectoryImageSource;
import org.grlea.imageTiles.imageSource.SingleImageSource;
import org.grlea.imageTiles.render.BevelEdgeDecorator;
import org.grlea.imageTiles.render.BorderDecorator;
import org.grlea.imageTiles.render.DecorativeTileRenderer;
import org.grlea.imageTiles.render.Decorator;
import org.grlea.imageTiles.render.GlareDecorator;
import org.grlea.imageTiles.render.PlainTileRenderer;
import org.grlea.imageTiles.render.RoundedCornerDecorator;
import org.grlea.imageTiles.swing.AnimatedTileIcon;

import java.awt.Component;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * <p></p>
 *
 * @author grlea
 * @version $Revision:$
 */
public class 
ConfigurationModel
{
   private int windowWidth = 400;

   private int windowHeight = 300;

   private int tileSize = 24;

   private int gapSize = 1;

   private boolean useSingleImage = true;

   private BufferedImage singleImage = null;

   private File imageDirectory = null;

   private boolean usePlainRenderer = false;

   private boolean decorateBevel = true;

   private boolean decorateRoundCorners = true;

   private boolean decorateGlare = true;

   private boolean decorateBorder = false;

   private boolean slideAnimator = true;

   private int animatedTileCount = 5;

   private int animationSpeed = 12;

   private int frameRate = 50;

   public
   ConfigurationModel()
   {
   }

   public void
   setUseSingleImage(boolean useSingleImage)
   {
      this.useSingleImage = useSingleImage;
   }

   public void
   setDirectory(File imageDirectory)
   {
      this.imageDirectory = imageDirectory;
   }

   public AnimatedTileIcon
   getAnimatedTileIcon(Component targetComponent)
   {
      TileSpace tileSpace = ImageTilesHelper.createTileSpace(targetComponent, tileSize, gapSize);

      ImageSource imageSource;
      if (useSingleImage)
      {
         imageSource = new SingleImageSource(singleImage);
      }
      else
      {
         ImageFileFilter imageFileFilter = new ImageFileFilter();
         try
         {
            imageSource = new DirectoryImageSource(imageDirectory, imageFileFilter, true);
         }
         catch (IOException e)
         {
            // TODO (grahaml) Do something else.
            throw new IllegalStateException("Need to dosomething else here!");
         }
      }

      TileRenderer tileRenderer;
      if (usePlainRenderer)
      {
         tileRenderer = new PlainTileRenderer();
      }
      else
      {
         ArrayList decoratorList = new ArrayList(4);
         if (decorateBorder)
            decoratorList.add(new BorderDecorator(tileSpace));
         if (decorateBevel)
            decoratorList.add(new BevelEdgeDecorator(tileSpace));
         if (decorateRoundCorners)
            decoratorList.add(new RoundedCornerDecorator(tileSpace));
         if (decorateGlare)
            decoratorList.add(new GlareDecorator(tileSpace));

         Decorator[] decorators =
            (Decorator[]) decoratorList.toArray(new Decorator[decoratorList.size()]);
         tileRenderer = new DecorativeTileRenderer(decorators);
      }

      Transition animator = null;
      if (slideAnimator)
         animator = new SlideTransition(animatedTileCount, animationSpeed);

      if (animator == null)
         animator = new BasicTransition();

      PipelineComponents pipelineComponents =
         new PipelineComponents(tileSpace, imageSource, tileRenderer, null, null, null, null,
                                animator);
      return new AnimatedTileIcon(targetComponent, new Pipeline(pipelineComponents), false);
   }
}