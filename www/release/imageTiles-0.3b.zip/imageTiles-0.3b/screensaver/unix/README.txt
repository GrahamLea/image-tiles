
                                 Image  Tiles

                                 Version 0.3b

                        http://image-tiles.dev.java.net/

LICENSE

Image Tiles is Copyright (c) 2004-2005 Graham Lea. All rights reserved.
Image Tiles is freely distributed under the Apache License 2.0.
See LICENSE.txt for details.


REQUIREMENTS

To run Image Tiles, you need a Java Runtime Environment (JRE) installed.
The version must be 1.4 or above.

                           Get Java   @   http://java.com/


INSTALL SCREENSAVER

To install the Image Tiles screensaver on un*x systems, you will need to look up and follow the
instructions in the screensaver development kit.
