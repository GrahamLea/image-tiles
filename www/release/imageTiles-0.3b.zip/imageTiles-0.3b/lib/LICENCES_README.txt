The following libraries are distributed with the Image Tiles release,
with many thanks to the developers.


elcore.jar:

Explicit Layout
Copyright � 2001 Zooki Technologies. All rights reserved.
http://www.zookitec.com/
License: LGPL (see LGPL.txt)



explicit-tablelayout-<version>.jar:

Explicit Table Layout
Copyright � 2004 Andrew Pietsch. All rights reserved.
http://pietschy.org/
License: LGPL (see LGPL.txt)



plastic-<version>.jar:

JGoodies Looks Plastic Look & Feel
Copyright (c) 2001-2004 JGoodies Karsten Lentzsch. All rights reserved.
http://looks.dev.java.net/
License: BSD-Style (see JGoodies_License.txt)
